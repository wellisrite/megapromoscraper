const scraper = require('./scraper.js');

scraper.main();